import XCTest
@testable import atlantisTests

XCTMain([
    testCase(atlantisTests.allTests),
])
